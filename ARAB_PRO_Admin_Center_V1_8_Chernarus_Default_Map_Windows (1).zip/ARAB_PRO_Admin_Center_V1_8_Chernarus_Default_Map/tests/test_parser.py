import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from admin_server import parse_line,trade_money
class TestParsers(unittest.TestCase):
    def test_raid(self):
        e=parse_line('[22/10/2026-17:40:56] [DESTROYED] [22/10/2026-17:40:56] A target was destroyed! | HDSN_BreachingChargeHeavy, Position: <3599.747803, 317.304810, 7426.383301>, Target: Fence_Gate | Player: scoroo [76561198972868854]','BreachingChargeLog_a.txt')
        self.assertEqual((e['kind'],e['action'],e['player_name'],e['details']),('raid','DESTROYED','scoroo','Fence_Gate'))
        self.assertAlmostEqual(e['x'],3599.747803)
    def test_login(self):
        e=parse_line('19.07.2026 12:15:39 [ZenMod] Player logged in: scoroo (76561198972868854) (pos=<1587.506348, 287.132965, 12315.944336>)','ZenMod_logins.log')
        self.assertEqual(e['action'],'LOGIN');self.assertEqual(e['x'],1587.506348)
    def test_self_death(self):
        e=parse_line('22.07.2026 15:25:51 [ZenMod] PLAYER PVP KILL: scoroo (76561198972868854) killed scoroo (76561198972868854) with SurvivorM_Oliver (pos=<6048.342285, 301.058197, 7842.750000>) (killerHealth=0)','ZenMod_pvp.log')
        self.assertEqual(e['action'],'SELF_DEATH')
    def test_money(self):
        self.assertEqual(trade_money([{'ClassName':'Arab_Pro_Riyal_Bill_500','Quantity':62},{'ClassName':'Arab_Pro_Riyal_Bill_500','Quantity':125}]),93500)
if __name__=='__main__':unittest.main()
