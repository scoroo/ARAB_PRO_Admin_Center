import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import admin_server as a

class SearchFiltersTest(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory()
        p=Path(self.t.name)
        self.p=p
        self.old=(a.DB_PATH,a.CONFIG_PATH)
        a.DB_PATH=p/'db.sqlite3'
        a.CONFIG_PATH=p/'config.json'
        a.setup()
        a.init_config()
        with a.db() as c:
            entry=a.mk('trade','COMPLETE','2026-10-29 12:10:15','76561190000000001','ExamplePlayer',
                       '76561190000000002','DemoBuyer','AKM','',extra={'tradeId':'DEMO-EXAMPLE'})
            a.add_event(c,'test','trade.jsonl',1,'trade',entry)
            entry=a.mk('raid','DESTROYED','2026-10-22 17:35:23','76561190000000001','',item='HDSN_BreachingChargeHeavy',pos='<3597,317,7415>',details='Fence_Gate')
            a.add_event(c,'test','raid.log',1,'raid',entry)
            entry=a.mk('player','LOGIN','2026-10-20 09:05:00','76561190000000003','OldAlias')
            a.add_event(c,'test','login.log',1,'login',entry)
            entry=a.mk('player','LOGOUT','2026-10-29 20:05:00','76561190000000003','NewName')
            a.add_event(c,'test','login.log',2,'logout',entry)
            c.execute('INSERT INTO bases(server,name,owner_id,x,z,radius,note,created_at) VALUES (?,?,?,?,?,?,?,?)',('test','شمال','76561190000000001',3597,7415,100,'near', '2026-10-29 12:13:00'))
            c.execute('INSERT INTO sources(server,path,size,mtime,updated_at) VALUES (?,?,?,?,?)',('test','mdt/players.log',100,0,'2026-10-22 12:00:00'))
            c.execute('INSERT INTO sources(server,path,size,mtime,updated_at) VALUES (?,?,?,?,?)',('test','Logs/Trades.jsonl',100,0,'2026-10-29 15:00:00'))
    def tearDown(self):
        a.DB_PATH,a.CONFIG_PATH=self.old
        self.t.cleanup()
    def test_date_time_and_action(self):
        xs=a.events('test',kind='raid',date_from='2026-10-22',date_to='2026-10-22',time_from='17:30',time_to='17:59',action='DESTROYED')
        self.assertEqual(len(xs),1)
        self.assertEqual(xs[0]['item'],'HDSN_BreachingChargeHeavy')
        self.assertEqual(a.events('test',kind='raid',time_from='18:00'),[])
        self.assertEqual(a.events('test',kind='trade',date_to='2026-10-28'),[])
    def test_alias_related_name_search(self):
        xs=a.events('test',kind='raid',q='ExamplePlayer')
        self.assertEqual(len(xs),1, 'Match player record linked by SteamID when event lacks a name')
        self.assertEqual(xs[0]['resolved_player_name'],'ExamplePlayer')
        xs=a.events('test',kind='player',q='OldAlias')
        self.assertEqual(len(xs),2, 'Search previous alias for events with renamed players')
        self.assertEqual(len(a.player_list('test',q='NewName')),1)
    def test_list_filters(self):
        self.assertEqual(len(a.player_list('test',date_from='2026-10-29')),3)
        self.assertEqual(len(a.player_list('test',time_from='20:00')),1)
        self.assertEqual(len(a.bases_filtered('test',q='ExamplePlayer',date_from='2026-10-29')),1)
        self.assertEqual(len(a.bases_filtered('test',time_to='12:00')),0)
        self.assertEqual(len(a.sources_filtered('test',q='Trades',date_from='2026-10-28')),1)
        self.assertEqual(a.actions_list('test','raid'),['DESTROYED'])
    def test_server_isolation_and_validation(self):
        self.assertEqual(a.events('main',q='ExamplePlayer'),[])
        with self.assertRaises(ValueError):a.events('test',date_from='2026-10-30',date_to='2026-10-21')
        with self.assertRaises(ValueError):a.events('test',time_from='bad')
        with self.assertRaises(ValueError):a.events('test',kind='invalid')
    def test_csv_export(self):
        blob=a.csv_export(['name','note'],[{'name':'=2+2','note':'A,B'}]).decode('utf-8-sig')
        self.assertIn("'=2+2",blob)
        self.assertIn('"A,B"',blob)

if __name__=='__main__':unittest.main()
