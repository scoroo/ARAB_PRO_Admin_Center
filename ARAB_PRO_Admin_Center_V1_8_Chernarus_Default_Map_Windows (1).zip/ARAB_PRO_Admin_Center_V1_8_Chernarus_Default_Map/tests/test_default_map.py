import unittest
from pathlib import Path
from PIL import Image
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import admin_server as s

class TestDefaultMap(unittest.TestCase):
    def test_map_default_available(self):
        self.assertTrue(s.DEFAULT_MAP_PATH.exists())
        self.assertEqual(s.map_image_source('test'), 'default')
        self.assertEqual(s.map_image_path('test'),s.DEFAULT_MAP_PATH)
        with Image.open(s.DEFAULT_MAP_PATH) as im:
            self.assertEqual(im.size,(2048,2048))

if __name__=='__main__':unittest.main()
