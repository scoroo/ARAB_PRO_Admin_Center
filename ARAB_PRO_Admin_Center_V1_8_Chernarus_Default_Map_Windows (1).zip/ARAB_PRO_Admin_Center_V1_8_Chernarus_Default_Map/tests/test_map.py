"""Tests for the V1.7 map read model with isolated synthetic sample records."""
import sys, tempfile, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import admin_server as a

class MapTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.old=a.DB_PATH,a.CONFIG_PATH,a.DATA
        root=Path(self.temp.name)
        a.DB_PATH=root/'admin.sqlite';a.CONFIG_PATH=root/'config.json';a.DATA=root
        a.setup();a.init_config()
        uid='76561190000000001'
        with a.db() as c:
            one=a.mk('raid','DESTROYED','2026-10-22 17:35:23',uid,'',item='BreachingCharge',pos='<3597,315,7415>',details='Fence_Gate')
            a.add_event(c,'test','raid.log',1,'RAID_EVENT',one)
            two=a.mk('combat','PVP_KILL','2026-10-23 20:35:23',uid,'ExamplePlayer','76561190000000002','Victim','AKM','<3712,312,7501>')
            a.add_event(c,'test','zen.log',2,'KILL_EVENT',two)
            three=a.mk('player','LOGIN','2026-10-23 19:00:00',uid,'ExamplePlayer')
            a.add_event(c,'test','login.log',3,'LOGIN_EVENT',three)
            c.execute('INSERT INTO bases(server,name,owner_id,x,z,radius) VALUES (?,?,?,?,?,?)',('test','Test Base',uid,3597,7415,170))
    def tearDown(self):
        a.DB_PATH,a.CONFIG_PATH,a.DATA=self.old
        self.temp.cleanup()
    def test_points_only_have_actual_coordinates(self):
        out=a.map_data('test')
        self.assertEqual({e['kind'] for e in out['events']},{'raid','combat'})
        self.assertEqual(len(out['bases']),1)
        self.assertEqual(out['map_size'],15360)
    def test_filters_time_name_server_and_kind(self):
        out=a.map_data('test',q='ExamplePlayer',kinds='raid',date_from='2026-10-22',date_to='2026-10-22')
        self.assertEqual(len(out['events']),1)
        self.assertEqual(out['events'][0]['resolved_player_name'],'ExamplePlayer')
        self.assertEqual(len(a.map_data('test',action='WRONG')['events']),0)
        self.assertEqual(len(a.map_data('main')['events']),0)
        self.assertEqual(len(a.map_data('test',kinds='__none__')['events']),0)
    def test_reject_unknown_kind(self):
        with self.assertRaises(ValueError):a.map_data('test',kinds='unauthorized')

if __name__=='__main__':unittest.main()
