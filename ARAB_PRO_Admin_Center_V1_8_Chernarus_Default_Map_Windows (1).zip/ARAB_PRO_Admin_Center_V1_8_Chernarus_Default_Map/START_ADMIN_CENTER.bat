@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  start "ARAB PRO Admin Service" cmd /k py -3 admin_server.py
) else (
  where python >nul 2>nul
  if %errorlevel%==0 (
    start "ARAB PRO Admin Service" cmd /k python admin_server.py
  ) else (
    echo Python 3 is required.
    pause
    exit /b 1
  )
)
timeout /t 2 /nobreak >nul
start "" "http://127.0.0.1:8765"
