@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 -m pip install Pillow arabic-reshaper python-bidi
) else (
  python -m pip install Pillow arabic-reshaper python-bidi
)
pause
