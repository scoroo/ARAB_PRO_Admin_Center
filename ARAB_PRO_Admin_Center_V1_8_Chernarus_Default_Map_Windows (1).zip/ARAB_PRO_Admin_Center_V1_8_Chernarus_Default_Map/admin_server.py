#!/usr/bin/env python3
"""ARAB PRO Admin Center — local, read-only DayZ log analytics (Windows friendly)."""
import argparse, csv, hashlib, hmac, secrets, io, json, mimetypes, os, re, sqlite3, threading, time
import urllib.parse, urllib.request, uuid, subprocess, collections
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

APP = Path(__file__).resolve().parent
DATA = APP / 'data'
DATA.mkdir(exist_ok=True)
DB_PATH = DATA / 'admin_center.sqlite3'
CONFIG_PATH = DATA / 'config.json'
MONEY_RE = re.compile(r'^Arab_Pro_Riyal_(?:Bill|Coin)_(\d+)$', re.I)
POS_RE = re.compile(r'<\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*>')
UID_RE = re.compile(r'\b76561\d{12}\b')
NAME_UID = r'(.+?)\s*\((76561\d{12})\)'
TS_ZEN = r'(\d{2}\.\d{2}\.\d{4}\s+\d{2}:\d{2}:\d{2})'
RE_ZEN_LOGIN = re.compile(r'^(.*?) \[ZenMod\] Player logged (in|out):\s*'+NAME_UID, re.I)
RE_ZEN_KILL = re.compile(r'^'+TS_ZEN+r' \[ZenMod\] PLAYER PVP KILL:\s*'+NAME_UID+r' killed '+NAME_UID+r' with (.+?)(?:\s*\(pos=|$)',re.I)
RE_ZEN_HIT = re.compile(r'^'+TS_ZEN+r' \[ZenMod\] PLAYER PVP HIT:\s*'+NAME_UID+r' hit '+NAME_UID+r' with (.+?)(?:\s*\(health=|$)',re.I)
RE_RAID = re.compile(r'^\[(\d{2}/\d{2}/\d{4}-\d{2}:\d{2}:\d{2})\]\s*\[(PLACED|ARMED|EXPLODED|DESTROYED)\].*?\|\s*([^,|]+),\s*Position:\s*(<[^>]+>),\s*Target:\s*([^|,]+).*?\|\s*Player:\s*(.*?)\s*\[(\d{17})\]',re.I)
RE_COURT = re.compile(r'^\[([^\]]+)\]\s*Judge:\s*(.*?)\s*\|\s*Target:\s*(\d{17})(?:\s*\(([^)]+)\))?\s*\|\s*Action:\s*([^|]+)\|\s*Details:\s*(.*)',re.I)
RE_VEH = re.compile(r'^(\d{10})\s+(REGISTER|REKEY|REPLACE|TRANSFER)\s+record=(\d+)\s+owner=(\d{17})(.*)',re.I)
RE_MCK = re.compile(r'^(\d\d:\d\d:\d\d)\s*\|\s*(.+?)\s*\(ID:\s*(\d+)\s*-\s*pos\s*(<[^>]+>)\)\s*initialized\.',re.I)
RE_TRADER = re.compile(r'^(\d\d:\d\d:\d\d)\s*\|\s*TraderObject:\s*(\S+)\s+spawned at\s*(<[^>]+>)',re.I)
RE_VEH_DEL = re.compile(r'^(\d\d:\d\d:\d\d\.\d+)\s+\[VehicleDeleted\]\s+(.+?)\s+\(id=(.*?)\s+pos=(<[^>]+>)',re.I)
RE_ZEN_INV = re.compile(r'^'+TS_ZEN+r' \[ZenMod\] PlayerInventory\s*\((\d{17})/([^)]+)\)',re.I)
VALID_SERVERS = {'main', 'test'}
WEBHOOK_KINDS = {
    'trade': 'التبادل التجاري', 'combat': 'القتل والقتال', 'player': 'دخول وخروج اللاعبين',
    'raid': 'الريدات والتفجير', 'court': 'المحكمة والسجن', 'vehicle': 'المركبات',
    'bank': 'البنك', 'trader': 'المتاجر',
    'mod_update': 'تحديثات المودات', 'server_health': 'تشغيل وإيقاف السيرفر'
}
ARCHITECT_DEFAULT_DIR = r'C:\Program Files (x86)\CFTools Software GmbH\Architect\Agent\deployments'
ARCHITECT_EVENTS = {'server.updated_mod', 'server.started', 'server.stopped'}
CONFIG_LOCK = threading.RLock()
DELIVERY_LOCK = threading.Lock()


ARABIC_CHARS_RE = re.compile(r'[\u0600-\u06FF]')
try:
    import arabic_reshaper
    from bidi.algorithm import get_display
except Exception:
    arabic_reshaper = None
    get_display = None
_AR_FORMS = {
    'ء': ('ﺀ','ﺀ',None,None), 'آ': ('ﺁ','ﺂ',None,None), 'أ': ('ﺃ','ﺄ',None,None), 'ؤ': ('ﺅ','ﺆ',None,None),
    'إ': ('ﺇ','ﺈ',None,None), 'ئ': ('ﺉ','ﺊ','ﺋ','ﺌ'), 'ا': ('ﺍ','ﺎ',None,None), 'ب': ('ﺏ','ﺐ','ﺑ','ﺒ'),
    'ة': ('ﺓ','ﺔ',None,None), 'ت': ('ﺕ','ﺖ','ﺗ','ﺘ'), 'ث': ('ﺙ','ﺚ','ﺛ','ﺜ'), 'ج': ('ﺝ','ﺞ','ﺟ','ﺠ'),
    'ح': ('ﺡ','ﺢ','ﺣ','ﺤ'), 'خ': ('ﺥ','ﺦ','ﺧ','ﺨ'), 'د': ('ﺩ','ﺪ',None,None), 'ذ': ('ﺫ','ﺬ',None,None),
    'ر': ('ﺭ','ﺮ',None,None), 'ز': ('ﺯ','ﺰ',None,None), 'س': ('ﺱ','ﺲ','ﺳ','ﺴ'), 'ش': ('ﺵ','ﺶ','ﺷ','ﺸ'),
    'ص': ('ﺹ','ﺺ','ﺻ','ﺼ'), 'ض': ('ﺽ','ﺾ','ﺿ','ﻀ'), 'ط': ('ﻁ','ﻂ','ﻃ','ﻄ'), 'ظ': ('ﻅ','ﻆ','ﻇ','ﻈ'),
    'ع': ('ﻉ','ﻊ','ﻋ','ﻌ'), 'غ': ('ﻍ','ﻎ','ﻏ','ﻐ'), 'ـ': ('ـ','ـ','ـ','ـ'), 'ف': ('ﻑ','ﻒ','ﻓ','ﻔ'),
    'ق': ('ﻕ','ﻖ','ﻗ','ﻘ'), 'ك': ('ﻙ','ﻚ','ﻛ','ﻜ'), 'ل': ('ﻝ','ﻞ','ﻟ','ﻠ'), 'م': ('ﻡ','ﻢ','ﻣ','ﻤ'),
    'ن': ('ﻥ','ﻦ','ﻧ','ﻨ'), 'ه': ('ﻩ','ﻪ','ﻫ','ﻬ'), 'و': ('ﻭ','ﻮ',None,None), 'ى': ('ﻯ','ﻰ',None,None),
    'ي': ('ﻱ','ﻲ','ﻳ','ﻴ'), 'ٱ': ('ﭐ','ﭑ',None,None), 'لا': ('ﻻ','ﻼ',None,None), 'لأ': ('ﻷ','ﻸ',None,None),
    'لإ': ('ﻹ','ﻺ',None,None), 'لآ': ('ﻵ','ﻶ',None,None), 'پ': ('ﭖ','ﭗ','ﭘ','ﭙ'), 'چ': ('ﭺ','ﭻ','ﭼ','ﭽ'),
    'ڤ': ('ﭪ','ﭫ','ﭬ','ﭭ'), 'گ': ('ﮒ','ﮓ','ﮔ','ﮕ')
}
_NON_JOINERS = set('اأإآدذرزوؤءةى')

def _ar_can_connect_left(ch):
    forms = _AR_FORMS.get(ch)
    return bool(forms and forms[1])

def _ar_can_connect_right(ch):
    forms = _AR_FORMS.get(ch)
    return bool(forms and forms[2]) and ch not in _NON_JOINERS

def _shape_ar_word(word):
    if not word:
        return word
    chars=[]
    i=0
    while i < len(word):
        pair = word[i:i+2]
        if pair in ('لا','لأ','لإ','لآ'):
            chars.append(pair)
            i += 2
        else:
            chars.append(word[i])
            i += 1
    out=[]
    for idx,ch in enumerate(chars):
        forms = _AR_FORMS.get(ch)
        if not forms:
            out.append(ch)
            continue
        prev = chars[idx-1] if idx > 0 else ''
        nxt = chars[idx+1] if idx + 1 < len(chars) else ''
        connect_prev = _ar_can_connect_right(prev) and _ar_can_connect_left(ch)
        connect_next = _ar_can_connect_right(ch) and _ar_can_connect_left(nxt)
        iso, fin, ini, med = forms
        if connect_prev and connect_next and med:
            out.append(med)
        elif connect_prev and fin:
            out.append(fin)
        elif connect_next and ini:
            out.append(ini)
        else:
            out.append(iso)
    return ''.join(reversed(out))


def rtl_text(text):
    s = str(text or '')
    if not ARABIC_CHARS_RE.search(s):
        return s
    if arabic_reshaper and get_display:
        try:
            return get_display(arabic_reshaper.reshape(s))
        except Exception:
            pass
    # Fallback local shaper when external packages are unavailable.
    runs = []
    current = []
    current_ar = None
    for ch in s:
        is_ar = bool(ARABIC_CHARS_RE.match(ch))
        if ch.isspace():
            if current:
                runs.append((current_ar, ''.join(current)))
                current = []
                current_ar = None
            runs.append((None, ch))
            continue
        if current_ar is None:
            current_ar = is_ar
            current.append(ch)
        elif current_ar == is_ar:
            current.append(ch)
        else:
            runs.append((current_ar, ''.join(current)))
            current = [ch]
            current_ar = is_ar
    if current:
        runs.append((current_ar, ''.join(current)))
    shaped = []
    for is_ar, run in runs:
        shaped.append(_shape_ar_word(run) if is_ar else run)
    return ''.join(shaped)


def default_webhooks():
    return {server:{kind:{'url':'','enabled':False,'auto':False,'min_id':0} for kind in WEBHOOK_KINDS}
            for server in VALID_SERVERS}


def init_config():
    with CONFIG_LOCK:
        if not CONFIG_PATH.exists():
            default={'servers':{'main':{'name':'السيرفر الرئيسي','root':''},
                       'test':{'name':'السيرفر التجريبي','root':''}},
                     'webhooks':default_webhooks(),'scan_interval_seconds':5,'health':{},
                     'architect':{'deployments_dir':ARCHITECT_DEFAULT_DIR,'token':secrets.token_urlsafe(30)}}
            save_config(default)
        conf=json.loads(CONFIG_PATH.read_text(encoding='utf-8-sig'))
        conf.setdefault('health',{})
        conf.setdefault('architect',{})
        conf['architect'].setdefault('deployments_dir',ARCHITECT_DEFAULT_DIR)
        if not conf['architect'].get('token'):
            conf['architect']['token']=secrets.token_urlsafe(30)
            save_config(conf)
        VALID_SERVERS.update(conf.get('servers',{}).keys())
        if 'webhooks' not in conf:
            # Preserve the older single trade webhook when upgrading V1.
            conf['webhooks']=default_webhooks()
            old=str(conf.get('discord_webhook') or '')
            if old:
                for server in list(VALID_SERVERS):
                    conf['webhooks'][server]['trade']['url']=old
                    conf['webhooks'][server]['trade']['enabled']=True
            save_config(conf)
        for server in list(VALID_SERVERS):
            conf['webhooks'].setdefault(server,{})
            for kind in WEBHOOK_KINDS:
                conf['webhooks'][server].setdefault(kind,{'url':'','enabled':False,'auto':False,'min_id':0})
        return conf


def save_config(conf):
    with CONFIG_LOCK:
        tmp=CONFIG_PATH.with_suffix('.tmp')
        tmp.write_text(json.dumps(conf,ensure_ascii=False,indent=2),encoding='utf-8')
        os.replace(tmp,CONFIG_PATH)




def discover_architect_deployments(conf=None):
    conf=conf or init_config()
    folder=Path(conf['architect']['deployments_dir'])
    if not folder.is_dir():
        return {'ok':False,'message':'مجلد Architect deployments غير موجود على كمبيوتر الخدمة','directory':str(folder),'deployments':[]}
    found=[]
    for child in sorted(folder.iterdir(),key=lambda p:p.name.lower()):
        if not child.is_dir() or child.name.startswith('.'):
            continue
        # Do not search arbitrary subtrees; match documented deployment layout only.
        candidates=[child/'profiles',child/'profile',child/'ServerProfile',child/'serverprofile']
        # Resolve Windows junctions normally only after explicit registration.
        profile=next((str(c) for c in candidates if c.is_dir()),'')
        linked=next((k for k,v in conf['servers'].items() if str(v.get('architect_id') or '')==child.name),'')
        found.append({'server_id':child.name,'path':str(child),'profile_candidate':profile,
                      'linked_server':linked,'linked_name':conf['servers'].get(linked,{}).get('name','')})
        if len(found)>=80:break
    return {'ok':True,'directory':str(folder),'deployments':found}


def link_architect_deployment(deployment_id,target='',name=''):
    deployment_id=str(deployment_id).strip()
    if not deployment_id or '/' in deployment_id or '\\' in deployment_id or deployment_id in {'.','..'}:
        raise ValueError('معرّف السيرفر غير صالح')
    with CONFIG_LOCK:
        conf=init_config()
        root=Path(conf['architect']['deployments_dir'])
        selected=root/deployment_id
        if not selected.is_dir() or selected.parent.resolve()!=root.resolve():
            raise ValueError('المجلد المحدد غير موجود ضمن Architect deployments')
        profile=next((str(p) for p in [selected/'profiles',selected/'profile',selected/'ServerProfile',selected/'serverprofile'] if p.is_dir()),'')
        current=next((k for k,v in conf['servers'].items() if v.get('architect_id')==deployment_id),'')
        if current and current!=target:raise ValueError('هذا السيرفر مرتبط بالفعل بـ '+conf['servers'][current]['name'])
        if target:
            if target not in conf['servers']:raise ValueError('السيرفر المحدد غير معروف')
            if conf['servers'][target].get('architect_id') not in (None,'',deployment_id):
                raise ValueError('السيرفر الحالي مرتبط بمجلد Architect مختلف')
            key=target
        else:
            key='arch_'+hashlib.sha256(deployment_id.encode('utf-8')).hexdigest()[:12]
            if key not in conf['servers']:
                conf['servers'][key]={'name':str(name or 'Architect '+deployment_id)[:90],'root':'','architect_id':deployment_id}
        record=conf['servers'][key]
        record['architect_id']=deployment_id
        record['deployment_root']=str(selected)
        if profile and not record.get('root'):
            record['root']=profile
        conf['webhooks'].setdefault(key,{k:{'url':'','enabled':False,'auto':False,'min_id':0} for k in WEBHOOK_KINDS})
        VALID_SERVERS.add(key)
        save_config(conf)
        return {'ok':True,'server':key,'name':record['name'],'root':record.get('root',''),
                'profile_detected':bool(profile)}


def architect_record(event_type,payload,delivery_id):
    # Architect events may be templated; exact field names below are the documented values.
    if event_type not in ARCHITECT_EVENTS:raise ValueError('حدث Architect غير مدعوم')
    sid=str(payload.get('server') or '').strip()
    conf=init_config()
    target=next((k for k,v in conf['servers'].items() if str(v.get('architect_id') or '')==sid),None)
    if not target:raise ValueError('معرّف السيرفر غير مرتبط في لوحة الإدارة: '+sid[:90])
    mod=str(payload.get('mod') or '')[:200]
    mod_id=str(payload.get('mod_id') or '')[:60]
    date=payload.get('date')
    try:ts=datetime.fromtimestamp(float(date),timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')
    except (ValueError,TypeError,OverflowError,OSError):ts=datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')
    kind='mod_update' if event_type=='server.updated_mod' else 'server_health'
    if kind=='mod_update' and not mod:raise ValueError('اسم المود غير موجود في حدث التحديث')
    reason=str(payload.get('reason') or '')[:80]
    e=mk(kind,event_type,ts,item=mod if kind=='mod_update' else '',
         details=('Steam Workshop ID: '+mod_id if mod_id else '') if kind=='mod_update' else ('Reason: '+reason if reason else ''),
         extra={'architect_server':sid,'mod_id':mod_id,'mod_name':mod,'reason':reason,'delivery_id':delivery_id})
    # Deduplicate by Architect's X-Event-Idempotence, preserving all distinct deliveries.
    rel='Architect/'+sid
    with db() as c:
        inserted=add_event(c,target,rel,delivery_id,json.dumps(payload,ensure_ascii=False,sort_keys=True),e)
        eid=c.execute('SELECT last_insert_rowid()').fetchone()[0] if inserted else None
    queued=queue_new_auto_events(target,[eid] if eid else [])
    return {'ok':True,'new':inserted,'queued':queued,'server':target}

def check_webhook(url):
    u=urllib.parse.urlparse(url)
    if (u.scheme!='https' or u.hostname not in {'discord.com','discordapp.com'}
            or not re.fullmatch(r'/api/webhooks/\d+/[A-Za-z0-9_-]+/?',u.path)
            or u.username or u.password or u.port not in (None,443) or u.query or u.fragment):
        raise ValueError('رابط Discord Webhook غير صحيح؛ استخدم رابط Discord الأصلي')
    return url


def db():
    c=sqlite3.connect(DB_PATH,timeout=30)
    c.row_factory=sqlite3.Row
    c.execute('PRAGMA journal_mode=WAL')
    c.execute('PRAGMA busy_timeout=20000')
    return c

def setup():
    with db() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY, server TEXT NOT NULL, kind TEXT NOT NULL, action TEXT,
            ts TEXT, player_id TEXT, player_name TEXT, target_id TEXT, target_name TEXT,
            item TEXT, x REAL, y REAL, z REAL, details TEXT, source TEXT,
            raw TEXT, digest TEXT UNIQUE, extra TEXT NOT NULL DEFAULT '{}'
        );
        CREATE INDEX IF NOT EXISTS ev_server_kind ON events(server, kind, id DESC);
        CREATE INDEX IF NOT EXISTS ev_player ON events(server, player_id, id DESC);
        CREATE TABLE IF NOT EXISTS players (
            server TEXT, uid TEXT, name TEXT, aliases TEXT DEFAULT '[]', last_seen TEXT,
            PRIMARY KEY(server,uid)
        );
        CREATE TABLE IF NOT EXISTS bases (
            id INTEGER PRIMARY KEY, server TEXT, name TEXT, owner_id TEXT,
            x REAL, z REAL, radius REAL, note TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS sources (
            server TEXT,path TEXT, size INTEGER,mtime REAL,updated_at TEXT,
            PRIMARY KEY(server,path)
        );
        CREATE TABLE IF NOT EXISTS outbox (
            event_id INTEGER PRIMARY KEY, trade_id TEXT UNIQUE, sent_at TEXT, result TEXT
        );
        CREATE TABLE IF NOT EXISTS webhook_deliveries (
            server TEXT NOT NULL, event_id INTEGER NOT NULL, kind TEXT NOT NULL,
            status TEXT NOT NULL, attempts INTEGER DEFAULT 0, error TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP, sent_at TEXT,
            PRIMARY KEY(server,event_id,kind)
        );
        CREATE TABLE IF NOT EXISTS webhook_sent_keys (
            server TEXT NOT NULL, kind TEXT NOT NULL, external_key TEXT NOT NULL,
            event_id INTEGER NOT NULL, PRIMARY KEY(server,kind,external_key)
        );
        ''')

def stamp(raw):
    raw=raw.strip()
    formats=['%d.%m.%Y %H:%M:%S','%d/%m/%Y-%H:%M:%S','%Y-%m-%d %H:%M:%S','%Y-%m-%dT%H:%M:%SZ']
    for f in formats:
        try: return datetime.strptime(raw,f).strftime('%Y-%m-%d %H:%M:%S')
        except ValueError: continue
    return raw

def coords(raw):
    m=POS_RE.search(raw)
    return tuple(map(float,m.groups())) if m else (None,None,None)

def mk(kind,action='',ts='',player_id='',player_name='',target_id='',target_name='',item='',pos='',details='',extra=None):
    x,y,z=coords(pos)
    return dict(kind=kind,action=action,ts=stamp(ts),player_id=player_id,player_name=player_name,
                target_id=target_id,target_name=target_name,item=item,x=x,y=y,z=z,
                details=details,extra=extra or {})

def parse_line(line, filename):
    """Only parse events supported by demonstrated source formats. Unmatched lines ignored."""
    s=line.strip()
    if not s: return None
    name=filename.lower()
    if 'breachingcharge' in name:
        m=RE_RAID.search(s)
        if m:
            ts,action,item,pos,target,pname,uid=m.groups()
            return mk('raid',action,ts,uid,pname,item=item.strip(),pos=pos,details=target.strip())
    if 'zenmod_logins' in name:
        m=RE_ZEN_LOGIN.search(s)
        if m:
            ts,action,pname,uid=m.groups()
            return mk('player','LOGIN' if action.lower()=='in' else 'LOGOUT',ts,uid,pname,pos=s)
    if 'zenmod_pvp' in name:
        m=RE_ZEN_KILL.search(s)
        if m:
            ts,pname,pid,tname,tid,weapon=m.groups()
            action='SELF_DEATH' if pid==tid else 'PVP_KILL'
            return mk('combat',action,ts,pid,pname,tid,tname,weapon.strip(),s)
    if 'zenmod_general' in name:
        m=RE_ZEN_HIT.search(s)
        if m:
            ts,pname,pid,tname,tid,weapon=m.groups()
            return mk('combat','PVP_HIT',ts,pid,pname,tid,tname,weapon.strip(),'',details=s[-70:])
    if name=='courtlogs.txt' or ('court' in name and name.endswith('.log')):
        m=RE_COURT.search(s)
        if m:
            ts,judge,uid,pname,action,details=m.groups()
            return mk('court',action.strip(),ts,uid,pname or '',details=details.strip(),extra={'judge':judge.strip()})
    if name.startswith('service_'):
        m=RE_VEH.search(s)
        if m:
            epoch,act,record,uid,tail=m.groups()
            ts=datetime.fromtimestamp(int(epoch), timezone.utc).strftime('%Y-%m-%d %H:%M:%S')
            extra=dict(re.findall(r'(\w+)=([^\s]+)',tail))
            extra['record']=record
            return mk('vehicle',act,ts,uid,item=extra.get('class',''),details=tail.strip(),extra=extra)
    if name.startswith('mckactivity'):
        m=RE_MCK.search(s)
        if m:
            t,vehicle,vid,pos=m.groups()
            return mk('vehicle','SNAPSHOT','',item=vehicle,pos=pos,details='MCK ID '+vid)
    if name.startswith('tm_generallogs'):
        m=RE_TRADER.search(s)
        if m:
            t,obj,pos=m.groups()
            return mk('trader','OBJECT_SPAWN','',item=obj,pos=pos)
    if name=='log.txt' or name.startswith('expansion'):
        m=RE_VEH_DEL.search(s)
        if m:
            t,item,vid,pos=m.groups()
            return mk('vehicle','DELETED','',item=item,pos=pos,details=vid)
    return None


def parse_json_records(path):
    """Return structured records only from recognized V2 audit / V3 vault / bank JSON."""
    nm=path.name.lower()
    if nm.endswith('.jsonl'):
        with path.open('r',encoding='utf-8-sig',errors='replace') as f:
            for lineno,line in enumerate(f,1):
                try: obj=json.loads(line)
                except (ValueError,TypeError):continue
                if obj.get('schema')!='apx-audit-v2.1': continue
                act=str(obj.get('eventType',''))
                ts=obj.get('recordedAtUTC','')
                extra={'tradeId':obj.get('tradeId',''), 'offeredByA':obj.get('offeredByA',[]),
                       'offeredByB':obj.get('offeredByB',[]), 'moneyTotalA':obj.get('moneyTotalA'),
                       'moneyTotalB':obj.get('moneyTotalB'), 'postId':obj.get('postId',''),
                       'reason':obj.get('reason',''), 'schema':'apx-audit-v2.1'}
                e=mk('trade',act,ts,obj.get('playerAUID',''),obj.get('playerAName',''),obj.get('playerBUID',''),obj.get('playerBName',''),details=obj.get('reason',''),extra=extra)
                yield lineno,line.rstrip(),e
    elif nm.endswith('.json'):
        try:obj=json.loads(path.read_text(encoding='utf-8-sig',errors='replace'))
        except (OSError,ValueError):return
        if not isinstance(obj,dict):return
        if obj.get('Schema','').startswith('apx-virtual-v3'):
            act=obj.get('Phase','')
            e=mk('trade',act, '', obj.get('PlayerA',''),target_id=obj.get('PlayerB',''),
                 details=obj.get('Note',''),extra={'tradeId':obj.get('TradeID',''),'postId':obj.get('PostID',''),
                 'offeredByA':obj.get('OfferA',[]),'offeredByB':obj.get('OfferB',[]),'schema':obj.get('Schema','')})
            yield 1,json.dumps(obj,ensure_ascii=False),e
        elif 'm_PlainID' in obj and 'm_OwnedCurrency' in obj:
            uid=str(obj.get('m_PlainID',''))
            e=mk('bank','BALANCE_SNAPSHOT',player_id=uid,player_name=obj.get('m_Username',''),details=str(obj.get('m_OwnedCurrency','')),extra={'balance':obj.get('m_OwnedCurrency')})
            yield 1,json.dumps({'uid':uid,'balance':obj.get('m_OwnedCurrency')},ensure_ascii=False),e
            for lineno,item in enumerate(obj.get('m_TransactionHistory',[]),2):
                if not isinstance(item,dict):continue
                e=mk('bank',str(item.get('m_Type','TRANSACTION')),str(item.get('m_Timestamp','')),uid,
                     details=str(item.get('m_Note','')),extra={'amount':item.get('m_Amount'),'balanceAfter':item.get('m_BalanceAfter')})
                yield lineno,json.dumps(item,ensure_ascii=False),e


def update_player(c,server,uid,name,ts):
    if not uid or not UID_RE.fullmatch(str(uid)):return
    name=(name or '').strip()
    old=c.execute('SELECT name,aliases,last_seen FROM players WHERE server=? AND uid=?',(server,uid)).fetchone()
    if old:
        aliases=json.loads(old['aliases'])
        if name and name not in aliases: aliases.append(name)
        use_new = bool(name and (not old['last_seen'] or (ts and ts>=old['last_seen'])))
        newname = name if use_new else old['name']
        last=max(str(old['last_seen'] or ''),str(ts or ''))
        c.execute('UPDATE players SET name=?,aliases=?,last_seen=? WHERE server=? AND uid=?', (newname,json.dumps(aliases,ensure_ascii=False),last,server,uid))
    else:
        c.execute('INSERT INTO players(server,uid,name,aliases,last_seen) VALUES(?,?,?,?,?)',(server,uid,name,json.dumps([name] if name else [],ensure_ascii=False),ts))

def add_event(c,server,rel,line,raw,e):
    digest=hashlib.sha256((server+'\0'+rel+'\0'+str(line)+'\0'+raw).encode('utf-8')).hexdigest()
    try:
        c.execute('''INSERT INTO events(server,kind,action,ts,player_id,player_name,target_id,target_name,
            item,x,y,z,details,source,raw,digest,extra) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
            (server,e['kind'],e['action'],e['ts'],e['player_id'],e['player_name'],e['target_id'],e['target_name'],
            e['item'],e['x'],e['y'],e['z'],e['details'],rel,raw[:6000],digest,json.dumps(e.get('extra',{}),ensure_ascii=False)))
    except sqlite3.IntegrityError:return 0
    update_player(c,server,str(e['player_id'] or ''),e['player_name'],e['ts'])
    update_player(c,server,str(e['target_id'] or ''),e['target_name'],e['ts'])
    return 1

# File dialogs must be opened by the LOCAL desktop application, not HTML alone.
# This function is invoked by a user click through the loopback HTTP service.
folder_pick_lock = threading.Lock()


def choose_server_folder(initial_directory=''):
    """Open the host machine's native folder dialog, returning a path or '' on cancel.

    Works when Python runs in an interactive Windows desktop session. A browser
    cannot read or send a native absolute directory path via <input type=file>.
    """
    try:
        import tkinter as tk
        from tkinter import filedialog
    except ImportError as ex:
        raise ValueError('اختيار المجلد يحتاج Python مع Tkinter. جرّب تثبيت Python الرسمي أو أدخل المسار يدويًا.') from ex
    root = None
    try:
        root = tk.Tk()
        root.withdraw()
        root.attributes('-topmost', True)
        root.lift()
        root.update()
        args = {'parent': root, 'title': 'ARAB PRO | اختر مجلد DayZ ServerProfile'}
        if initial_directory and Path(initial_directory).is_dir():
            args['initialdir'] = initial_directory
        selected = filedialog.askdirectory(**args)
        return str(Path(selected).resolve()) if selected else ''
    except (tk.TclError, OSError) as ex:
        raise ValueError('تعذّر فتح نافذة اختيار المجلد على جهاز الخدمة. شغّل START_ADMIN_CENTER.bat على سطح مكتب Windows أو أدخل المسار يدويًا.') from ex
    finally:
        if root is not None:
            root.destroy()


scan_lock=threading.Lock()
def allowed_files(root):
    root=Path(root).resolve()
    n=0
    for dirpath,dirs,files in os.walk(root,followlinks=False):
        rel=Path(dirpath).relative_to(root)
        if len(rel.parts)>6:
            dirs[:]=[];continue
        dirs[:]=[x for x in dirs if x.lower() not in {'steamapps','addons','workshop','node_modules','.git','backup','backups'}]
        for name in files:
            if n>=3000:return
            p=Path(dirpath)/name
            if p.is_symlink():continue
            suffix=p.suffix.lower()
            if suffix not in {'.txt','.log','.json','.jsonl','.adm','.rpt'}:continue
            if suffix=='.json' and not (name.lower().endswith('.json') and (name[0].isdigit() or 'vault' in str(p).lower() or 'trade' in str(p).lower() or 'bank' in str(p).lower())): continue
            if suffix=='.txt' and not any(t in name.lower() for t in ['court','breach','service','trade','log']):continue
            n+=1;yield p

def scan(server):
    if server not in VALID_SERVERS:raise ValueError('Unknown server')
    conf=init_config()
    root=(conf['servers'][server].get('root') or '').strip()
    if not root:return {'new':0,'sources':0,'message':'حدد مسار ملفات السيرفر من الإعدادات أولًا'}
    path=Path(root)
    if not path.is_dir():return {'new':0,'sources':0,'message':'المجلد غير موجود: '+root}
    if not scan_lock.acquire(blocking=False):return {'new':0,'sources':0,'message':'الفحص جارٍ بالفعل'}
    try:
        total=0;count=0;skipped=0; inserted_ids=[]
        with db() as c:
            for p in allowed_files(path):
                try:
                    st=p.stat()
                    if st.st_size>32*1024*1024:skipped+=1;continue
                    rel=str(p.relative_to(path))
                    old=c.execute('SELECT size,mtime FROM sources WHERE server=? AND path=?',(server,rel)).fetchone()
                    if old and old['size']==st.st_size and old['mtime']==st.st_mtime:continue
                    if p.suffix.lower() in {'.json','.jsonl'}:
                        iterator=parse_json_records(p)
                    else:
                        def lines():
                            with p.open('r',encoding='utf-8-sig',errors='replace') as fh:
                                for num,line in enumerate(fh,1):
                                    e=parse_line(line,p.name)
                                    if e: yield num,line.rstrip(),e
                        iterator=lines()
                    try:
                        for ln,raw,e in iterator:
                            n=add_event(c,server,rel,ln,raw,e)
                            total+=n
                            if n:inserted_ids.append(c.execute('SELECT last_insert_rowid()').fetchone()[0])
                    except (OSError,UnicodeError,ValueError):skipped+=1;continue
                    count+=1
                    c.execute('INSERT INTO sources(server,path,size,mtime,updated_at) VALUES(?,?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(server,path) DO UPDATE SET size=excluded.size,mtime=excluded.mtime,updated_at=CURRENT_TIMESTAMP',(server,rel,st.st_size,st.st_mtime))
                except (OSError, UnicodeError, ValueError):
                    skipped+=1
                    continue
        queued=queue_new_auto_events(server,inserted_ids)
        return {'new':total,'sources':count,'skipped':skipped,'queued_webhooks':queued,
                'message':'تم فحص ملفات السيرفر بنجاح'}
    finally:scan_lock.release()



# Statistics use observed LOGIN/LOGOUT logs, not inferred actual DayZ player counts.
def attendance_stats(server,date_from='',date_to=''):
    _valid_search_date(date_from);_valid_search_date(date_to)
    with db() as c:
        logins=rows(c,"SELECT id,ts,player_id,action,COALESCE(NULLIF(player_name,''),p.name,player_id) name "
                    "FROM events e LEFT JOIN players p ON p.server=e.server AND p.uid=e.player_id "
                    "WHERE e.server=? AND e.kind='player' AND e.action IN ('LOGIN','LOGOUT') "
                    "AND length(e.ts)>=19 ORDER BY e.ts ASC,e.id ASC",(server,))
    sessions=[];open_s={};logins_count=0;logouts_count=0;hours=[0]*24;days=[0]*7;durations=[];unique=set()
    for e in logins:
        try:dt=datetime.strptime(e['ts'][:19],'%Y-%m-%d %H:%M:%S')
        except (TypeError,ValueError):continue
        uid=e['player_id'] or ''
        if not uid:continue
        key=e['action']
        inside=(not date_from or dt.date().isoformat()>=date_from) and (not date_to or dt.date().isoformat()<=date_to)
        if key=='LOGIN':
            # Consecutive logins without a logout do not form an invented session.
            open_s[uid]=(dt,e['name'])
            if inside:
                logins_count+=1;unique.add(uid);hours[dt.hour]+=1;days[dt.weekday()]+=1
        else:
            if inside:logouts_count+=1
            previous=open_s.pop(uid,None)
            if previous:
                start,name=previous;minutes=(dt-start).total_seconds()/60
                if 0<=minutes<=24*60 and ((not date_from or start.date().isoformat()>=date_from) and (not date_to or start.date().isoformat()<=date_to)):
                    durations.append(minutes)
                    sessions.append({'name':name,'uid':uid,'start':start.isoformat(' '),'end':dt.isoformat(' '),'minutes':round(minutes,1)})
    return {'logins':logins_count,'logouts':logouts_count,'unique':len(unique),
            'avg_session_min':round(sum(durations)/len(durations),1) if durations else None,
            'paired_sessions':len(durations),'unpaired_login_ids':len(open_s),
            'peak_login_hour':max(range(24),key=lambda i:hours[i]) if sum(hours) else None,
            'hourly_logins':[{'hour':f'{i:02d}:00','count':hours[i]} for i in range(24)],
            'weekday_logins':[{'day':name,'count':days[i]} for i,name in enumerate(['الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت','الأحد'])],
            'sessions':list(reversed(sessions[-150:]))}

ERROR_MARKERS=('access_violation','exception','error','crash','script error','segmentation fault','fatal')
def diagnostics(server):
    conf=init_config();root=str(conf['servers'][server].get('root') or '').strip()
    files=[];samples=[]
    if root and Path(root).is_dir():
        # Search only recent .RPT/script logs and bound the scan to the last 2MB per file.
        candidates=[]
        base=Path(root)
        for directory in [base,base/'logs',base/'Logs',base/'CrashLogs']:
            if not directory.is_dir():continue
            for f in directory.iterdir():
                if f.is_file() and (f.suffix.lower()=='.rpt' or (f.suffix.lower()=='.log' and ('script' in f.name.lower() or 'crash' in f.name.lower()))):
                    try:candidates.append((f.stat().st_mtime,f))
                    except OSError:pass
        for _,path in sorted(candidates,reverse=True)[:6]:
            try:
                with path.open('rb') as fp:
                    fp.seek(max(0,path.stat().st_size-2_000_000))
                    data=fp.read().decode('utf-8',errors='replace')
                matched=[line.strip()[:350] for line in data.splitlines() if any(k in line.lower() for k in ERROR_MARKERS)]
                files.append({'name':path.name,'errors':len(matched)})
                for line in matched[-8:]:samples.append({'file':path.name,'line':line})
            except OSError:pass
    return {'root':root,'files':files,'errors':samples[-32:]}

HEALTH_STATE={}
HEALTH_LOCK=threading.Lock()
def check_server_processes():
    # Prefer psutil when installed. Fall back to PowerShell/CIM on Windows.
    try:
        import psutil
        return [str(' '.join(p.info.get('cmdline') or [])) for p in psutil.process_iter(['name','cmdline'])
                if str(p.info.get('name') or '').lower() in ('dayzserver_x64.exe','dayzserver.exe')]
    except ImportError:pass
    except Exception:pass
    if os.name!='nt':return None
    script="Get-CimInstance Win32_Process -Filter \"Name='DayZServer_x64.exe'\" | Select-Object -ExpandProperty CommandLine"
    try:
        run=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',script],
                           capture_output=True,text=True,timeout=12,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        if run.returncode:return None
        return [x for x in run.stdout.splitlines() if x.strip()]
    except (OSError,subprocess.TimeoutExpired):return None

def health_snapshot(server):
    cfg=init_config()['health'].get(server,{})
    with HEALTH_LOCK: state=dict(HEALTH_STATE.get(server,{}) or {})
    if not cfg.get('enabled') or not cfg.get('match'):
        return {'enabled':False,'state':'UNCONFIGURED','match':cfg.get('match',''),'last_check':state.get('last_check','')}
    return {'enabled':True,'state':state.get('state','CHECKING'),'match':cfg['match'],
            'last_check':state.get('last_check',''),'last_change':state.get('last_change','')}

def health_monitor():
    # Must run outside DayZ process, under an active Windows session/service.
    while True:
        try:
            conf=init_config();processes=check_server_processes()
            now=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            for server,item in conf.get('health',{}).items():
                if not item.get('enabled') or not item.get('match') or server not in VALID_SERVERS:continue
                if processes is None:continue # missing permission/tool: no false DOWN alerts
                selector=item['match'].lower()
                alive=any(selector in line.lower() for line in processes)
                with HEALTH_LOCK:
                    state=HEALTH_STATE.setdefault(server,{'state':'CHECKING','misses':0,'last_change':now})
                    state['last_check']=now
                    state['misses']=0 if alive else state.get('misses',0)+1
                    next_state='RUNNING' if alive else ('STOPPED' if state['misses']>=2 else state.get('state','CHECKING'))
                    old_state=state['state']
                    state['state']=next_state
                    changed=next_state!=old_state
                    if changed:state['last_change']=now
                if changed and old_state in {'RUNNING','STOPPED'} and next_state in {'RUNNING','STOPPED'}:
                    action='RECOVERED' if next_state=='RUNNING' else 'STOPPED'
                    hints=diagnostics(server)['errors'][-3:] if action=='STOPPED' else []
                    extra={'diagnostics':hints}
                    ev=mk('server_health',action,now,details='إشعار مراقبة العملية؛ الأخطاء في الملف مؤشرات وليست سببًا مؤكدًا',extra=extra)
                    raw='HEALTH:'+server+':'+action+':'+now
                    with db() as c:
                        inserted=add_event(c,server,'health_monitor',0,raw,ev)
                        eid=c.execute('SELECT last_insert_rowid()').fetchone()[0] if inserted else None
                    if eid:queue_new_auto_events(server,[eid])
            time.sleep(10)
        except Exception as ex:
            print('[HEALTH WARNING]',ex);time.sleep(15)


def as_dict(row):return dict(row) if row else {}
def rows(c,sql,params=()):return [dict(x) for x in c.execute(sql,params).fetchall()]
def _valid_search_date(value):
    value=str(value or '').strip()
    if not value:return ''
    try:
        datetime.strptime(value, '%Y-%m-%d')
    except ValueError:
        raise ValueError('صيغة التاريخ غير صحيحة؛ استخدم YYYY-MM-DD')
    return value


def _valid_search_time(value):
    value=str(value or '').strip()
    if not value:return ''
    if not re.fullmatch(r'(?:[01][0-9]|2[0-3]):[0-5][0-9]',value):
        raise ValueError('صيغة الوقت غير صحيحة؛ استخدم HH:MM')
    return value


def apply_date_filters(where,params,field,date_from='',date_to='',time_from='',time_to=''):
    """Compare normalized log-local timestamp text. Don't assume source timezone."""
    date_from=_valid_search_date(date_from)
    date_to=_valid_search_date(date_to)
    time_from=_valid_search_time(time_from)
    time_to=_valid_search_time(time_to)
    if date_from and date_to and date_from>date_to:
        raise ValueError('تاريخ البداية بعد تاريخ النهاية')
    if time_from and time_to and time_from>time_to:
        raise ValueError('وقت البداية بعد وقت النهاية')
    if date_from: where.append('substr('+field+',1,10)>=?');params.append(date_from)
    if date_to: where.append('substr('+field+',1,10)<=?');params.append(date_to)
    if time_from: where.append('substr('+field+',12,5)>=?');params.append(time_from)
    if time_to: where.append('substr('+field+',12,5)<=?');params.append(time_to)


def filters(server,kind='',q='',action='',date_from='',date_to='',time_from='',time_to='',player_uid=''):
    where=['e.server=?'];params=[server]
    if kind:
        if kind not in WEBHOOK_KINDS: raise ValueError('نوع السجل غير معروف')
        where.append('e.kind=?');params.append(kind)
    if action:
        where.append('e.action=?');params.append(action[:100])
    if player_uid:
        where.append('(e.player_id=? OR e.target_id=?)');params.extend([player_uid,player_uid])
    if q:
        needle='%'+q.strip()[:100]+'%'
        cols=['player_name','target_name','player_id','target_id','item','action','details','raw','extra','source']
        terms=["COALESCE(e."+a+",'') LIKE ?" for a in cols]
        terms.append("EXISTS (SELECT 1 FROM players ep WHERE ep.server=e.server AND ep.uid IN (e.player_id,e.target_id) AND (ep.name LIKE ? OR ep.aliases LIKE ?))")
        where.append('('+' OR '.join(terms)+')')
        params.extend([needle]*len(cols)+[needle,needle])
    apply_date_filters(where,params,'e.ts',date_from,date_to,time_from,time_to)
    return ' AND '.join(where),params


def players_filtered(server,q='',date_from='',date_to='',time_from='',time_to=''):
    where=['p.server=?'];params=[server]
    if q:
        where.append('(p.name LIKE ? OR p.uid LIKE ? OR p.aliases LIKE ?)')
        params += ['%'+q.strip()[:100]+'%']*3
    apply_date_filters(where,params,'p.last_seen',date_from,date_to,time_from,time_to)
    with db() as c:
        return rows(c,'SELECT p.* FROM players p WHERE '+' AND '.join(where)+' ORDER BY p.last_seen DESC LIMIT 1000',params)


def bases_filtered(server,q='',date_from='',date_to='',time_from='',time_to=''):
    where=['b.server=?'];params=[server]
    if q:
        needle='%'+q.strip()[:100]+'%'
        where.append('(b.name LIKE ? OR b.owner_id LIKE ? OR b.note LIKE ? OR p.name LIKE ? OR p.aliases LIKE ?)')
        params += [needle]*5
    apply_date_filters(where,params,'b.created_at',date_from,date_to,time_from,time_to)
    with db() as c:
        return rows(c,"SELECT b.*, COALESCE(p.name,'') AS owner_name FROM bases b LEFT JOIN players p ON p.server=b.server AND p.uid=b.owner_id WHERE "+' AND '.join(where)+' ORDER BY b.id DESC LIMIT 2000',params)


def sources_filtered(server,q='',date_from='',date_to='',time_from='',time_to=''):
    where=['s.server=?'];params=[server]
    if q:
        where.append('s.path LIKE ?');params.append('%'+q.strip()[:100]+'%')
    apply_date_filters(where,params,'s.updated_at',date_from,date_to,time_from,time_to)
    with db() as c:
        return rows(c,'SELECT s.* FROM sources s WHERE '+' AND '.join(where)+' ORDER BY s.updated_at DESC LIMIT 1000',params)


def actions_list(server,kind=''):
    with db() as c:
        if kind:
            if kind not in WEBHOOK_KINDS:raise ValueError('نوع السجل غير معروف')
            result=rows(c,"SELECT DISTINCT action FROM events WHERE server=? AND kind=? AND action<>'' ORDER BY action",(server,kind))
        else:
            result=rows(c,"SELECT DISTINCT action FROM events WHERE server=? AND action<>'' ORDER BY action",(server,))
        return [x['action'] for x in result]

def find_base(c,server,x,z):
    if x is None or z is None:return None
    matches=[]
    for r in c.execute('SELECT * FROM bases WHERE server=?',(server,)).fetchall():
        if ((r['x']-x)**2+(r['z']-z)**2)**0.5 <=r['radius']:matches.append(dict(r))
    return matches[0] if len(matches)==1 else None

def attach_base(c,e):
    e['base']=find_base(c,e['server'],e['x'],e['z']) if e['kind']=='raid' else None
    return e

def overview(server):
    with db() as c:
        counts={x['kind']:x['n'] for x in rows(c,'SELECT kind,COUNT(*) n FROM events WHERE server=? GROUP BY kind',(server,))}
        info={ 'total':sum(counts.values()),'players':c.execute('SELECT COUNT(*) FROM players WHERE server=?',(server,)).fetchone()[0],
          'pvp_kills':c.execute("SELECT COUNT(*) FROM events WHERE server=? AND action='PVP_KILL'",(server,)).fetchone()[0],
          'raids':counts.get('raid',0),'raid_destroyed':c.execute("SELECT COUNT(*) FROM events WHERE server=? AND kind='raid' AND action='DESTROYED'",(server,)).fetchone()[0],
          'trades_complete':c.execute("SELECT COUNT(*) FROM events WHERE server=? AND kind='trade' AND action='COMPLETE'",(server,)).fetchone()[0],
          'counts':counts, 'recent':[attach_base(c,x) for x in rows(c,'SELECT e.* FROM events e WHERE server=? ORDER BY id DESC LIMIT 15',(server,))]}
    return info

def events(server,kind='',q='',limit=250,action='',date_from='',date_to='',time_from='',time_to='',player_uid=''):
    where,params=filters(server,kind,q,action,date_from,date_to,time_from,time_to,player_uid)
    try: cap=min(max(int(limit),1),2000)
    except ValueError: cap=250
    with db() as c:
        es=rows(c,"SELECT e.*,COALESCE(NULLIF(e.player_name,''),p1.name,'') AS resolved_player_name,"
                    "COALESCE(NULLIF(e.target_name,''),p2.name,'') AS resolved_target_name "
                    'FROM events e '
                    'LEFT JOIN players p1 ON p1.server=e.server AND p1.uid=e.player_id '
                    'LEFT JOIN players p2 ON p2.server=e.server AND p2.uid=e.target_id '
                    'WHERE '+where+' ORDER BY e.id DESC LIMIT ?',params+[cap])
        return [attach_base(c,x) for x in es]

MAP_WORLD_SIZE=15360  # Chernarus+ default extent, X west-east / Z south-north.
DEFAULT_MAP_PATH=APP/'assets'/'chernarus_default.png'

def map_image_path(server):
    """Prefer a server-specific override, falling back to the packaged satellite map."""
    specific=DATA/'maps'/(server+'.png')
    return specific if specific.is_file() else DEFAULT_MAP_PATH

def map_image_source(server):
    return 'custom' if (DATA/'maps'/(server+'.png')).is_file() else ('default' if DEFAULT_MAP_PATH.is_file() else 'none')

MAP_KINDS={'raid','combat','vehicle','player','trade','trader','court'}

def map_data(server,q='',action='',date_from='',date_to='',time_from='',time_to='',kinds=''):
    requested={k.strip() for k in str(kinds).split(',') if k.strip()}
    selected=set() if kinds=='__none__' else ((requested & MAP_KINDS) if requested else MAP_KINDS)
    if requested and not selected and kinds!='__none__':raise ValueError('أنواع علامات الخريطة غير معروفة')
    where,params=filters(server,'',q,action,date_from,date_to,time_from,time_to)
    where+=' AND e.x IS NOT NULL AND e.z IS NOT NULL'
    where+=' AND e.kind IN ('+','.join('?' for _ in selected)+')'
    params+=sorted(selected)
    with db() as c:
        es=rows(c,"SELECT e.id,e.server,e.kind,e.action,e.ts,e.player_id,e.player_name,e.target_id,e.target_name,"
                    "e.item,e.x,e.y,e.z,e.details,e.extra,COALESCE(NULLIF(e.player_name,''),p1.name,'') AS resolved_player_name,"
                    "COALESCE(NULLIF(e.target_name,''),p2.name,'') AS resolved_target_name "
                    "FROM events e LEFT JOIN players p1 ON p1.server=e.server AND p1.uid=e.player_id "
                    "LEFT JOIN players p2 ON p2.server=e.server AND p2.uid=e.target_id "
                    "WHERE "+where+" ORDER BY e.id DESC LIMIT 4001",params)
        # Bases are intentionally managed by admins and may be returned independent of event filters.
        bs=rows(c,"SELECT b.*,COALESCE(p.name,'') AS owner_name FROM bases b "
                  "LEFT JOIN players p ON p.server=b.server AND p.uid=b.owner_id WHERE b.server=? ORDER BY b.id DESC LIMIT 1000",(server,))
    return {'events':es[:4000], 'bases':bs, 'truncated':len(es)>4000,
            'map_size':MAP_WORLD_SIZE, 'map_image':map_image_path(server).is_file(), 'map_image_source':map_image_source(server)}

def player_list(server,q='',date_from='',date_to='',time_from='',time_to=''):
    return players_filtered(server,q,date_from,date_to,time_from,time_to)

def trade_money(offer):
    total=0
    for obj in offer:
        if not isinstance(obj,dict):continue
        cm=MONEY_RE.fullmatch(str(obj.get('ClassName','')))
        if cm:
            try:total+=int(cm.group(1))*float(obj.get('Quantity') or 1)
            except (ValueError,TypeError):pass
    return round(total)

def image_trade(event):
    try:from PIL import Image, ImageDraw, ImageFont
    except ImportError:raise RuntimeError('إنشاء صور Discord يحتاج Pillow: py -m pip install Pillow')
    W,H=1140,680
    im=Image.new('RGB',(W,H),'#0a0c11');d=ImageDraw.Draw(im)
    d.rounded_rectangle((15,15,W-15,H-15),radius=25,fill='#111720',outline='#a91d30',width=3)
    d.rounded_rectangle((30,30,W-30,202),radius=20,fill='#1c1018')
    d.rectangle((30,190,1110,202),fill='#aa1b31')
    d.rounded_rectangle((40,222,545,563),radius=18,fill='#132025',outline='#1b684e',width=3)
    d.rounded_rectangle((572,222,1100,563),radius=18,fill='#29191d',outline='#81313b',width=3)
    for fp in ['C:/Windows/Fonts/tahoma.ttf','C:/Windows/Fonts/arial.ttf','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf']:
        if Path(fp).exists():break
    else: fp=None
    def font(sz):return ImageFont.truetype(fp,sz) if fp else ImageFont.load_default()
    fa=font(35); fsm=font(24); fbig=font(39); fs=font(21)
    def ar(text,x,y,fill='#f1f4f9',f=None):
        d.text((x,y),rtl_text(text),fill=fill,font=f or fsm,anchor='ra')
    logo=Image.open(APP/'assets/logo.png').convert('RGBA');logo.thumbnail((165,165))
    im.paste(logo,(49,34),logo)
    ar('سجل صفقات اللاعبين',1080,60,f=fa)
    ar('ARAB PRO  |  TRADE REPORT',1080,113,fill='#da9ea6',f=fs)
    extra=json.loads(event['extra'] or '{}')
    a=event['player_name'] or event['player_id'] or 'Player A';b=event['target_name'] or event['target_id'] or 'Player B'
    ar('الطرف الأول',510,250,fill='#62e2b1')
    d.text((60,315),a[:25],font=fbig,fill='white')
    ar('الطرف الثاني',1060,250,fill='#ff9ba5')
    d.text((594,315),b[:25],font=fbig,fill='white')
    def offerline(offer):
        return '  |  '.join((x if isinstance(x,str) else str(x.get('ClassName','Item')))[:27] for x in offer[:7])[:70] or '—'
    aa=extra.get('offeredByA',[]) or [];bb=extra.get('offeredByB',[]) or []
    d.text((60,403),offerline(aa),font=fs,fill='#d4e9e7')
    d.text((595,403),offerline(bb),font=fs,fill='#f6d8d9')
    def amount(of,key):
        if of and isinstance(of[0],dict):return trade_money(of)
        return extra.get(key) or 0
    ar('القيمة',515,465,fill='#ffda88',f=fs)
    d.text((515,497),f"{amount(aa,'moneyTotalA')} Riyal",font=fs,fill='#ffda88',anchor='ra')
    ar('القيمة',1060,465,fill='#ffda88',f=fs)
    d.text((1060,497),f"{amount(bb,'moneyTotalB')} Riyal",font=fs,fill='#ffda88',anchor='ra')
    ar('الحالة',930,584,fill='#ffda88',f=fsm)
    d.text((1075,584),(rtl_text('مكتملة') if event['action']=='COMPLETE' else str(event['action'])),font=fsm,fill='#62e2b1' if event['action']=='COMPLETE' else '#ffda88',anchor='ra')
    tradeid=str(extra.get('tradeId',''))[:52]
    d.text((42,600),'Trade ID: '+tradeid,font=fs,fill='#95a3b6')
    ar('الوقت',900,631,fill='#7b8a9b',f=fs)
    d.text((1075,631),str(event['ts'] or ''),font=fs,fill='#7b8a9b',anchor='ra')
    buf=io.BytesIO();im.save(buf,'PNG');return buf.getvalue()

def image_event(event):
    """Generate a consistent Arabic image for non-trade categories."""
    try:from PIL import Image, ImageDraw, ImageFont
    except ImportError:raise ValueError('تحتاج Pillow لصناعة الصور: شغّل INSTALL_IMAGE_REPORTS.bat')
    W,H=1140,680
    im=Image.new('RGB',(W,H),'#0b0e16');d=ImageDraw.Draw(im)
    accent={'combat':'#fa3549','raid':'#fa3549','player':'#278dc4',
            'vehicle':'#3caf91','bank':'#d2a44e','trader':'#3caf91',
            'mod_update':'#e1a04b','server_health':'#759bd5'}.get(event['kind'],'#fa3549')
    d.rounded_rectangle((14,14,W-14,H-14),radius=25,fill='#121a25',outline=accent,width=4)
    d.rounded_rectangle((33,32,W-33,202),radius=20,fill='#171421')
    d.rectangle((35,196,W-35,203),fill=accent)
    d.rounded_rectangle((37,228,1103,583),radius=18,fill='#192330',outline='#3a4454',width=2)
    font_path=next((f for f in ['C:/Windows/Fonts/tahoma.ttf','C:/Windows/Fonts/arial.ttf',
             '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'] if Path(f).exists()),None)
    def font(size):return ImageFont.truetype(font_path,size) if font_path else ImageFont.load_default()
    large=font(39);normal=font(28);medium=font(25);tiny=font(19)
    def ar(text,x,y,fill='white',f=None):
        d.text((x,y),rtl_text(text or '—'),fill=fill,font=f or normal,anchor='ra')
    logo=Image.open(APP/'assets/logo.png').convert('RGBA');logo.thumbnail((165,165))
    im.paste(logo,(46,35),logo)
    title={'combat':'سجل القتل والقتال','player':'سجل نشاط اللاعبين',
           'raid':'سجل اقتحام القواعد','court':'سجل المحكمة والسجن',
           'vehicle':'سجل المركبات','bank':'سجل البنك','trader':'سجل المتاجر',
           'mod_update':'تحديث مودات السيرفر','server_health':'تشغيل وإيقاف السيرفر'}.get(event['kind'],'سجل السيرفر')
    ar(title,1074,57,f=large)
    ar('ARAB PRO  |  '+event['kind'].upper()+' REPORT',1074,123,fill='#a6b3c3',f=medium)
    ar('السيرفر' if event['kind'] in {'mod_update','server_health'} else 'اللاعب',1050,257,fill=accent,f=normal)
    d.text((65,262),str((json.loads(event.get('extra') or '{}').get('architect_server') if event['kind'] in {'mod_update','server_health'} else event.get('player_name') or event.get('player_id')) or '—')[:50],font=large,fill='#f2f5fb')
    ar('الحدث',1050,340,fill=accent)
    activity=('تم تحديث المود' if event['kind']=='mod_update' and event['action']=='server.updated_mod' else str(event.get('action') or '—'))
    d.text((65,354),rtl_text(activity)[:70],font=normal,fill='#f1f3f7')
    target=event.get('target_name') or event.get('target_id') or ''
    if target:
        ar('الطرف الآخر',1050,418,fill=accent)
        d.text((65,432),str(target)[:60],font=normal,fill='white')
    item=str(event.get('item') or '')
    if item:
        ar('اسم المود' if event['kind']=='mod_update' else 'السلاح / القطعة',1050,493,fill=accent)
        d.text((65,508),item[:72],font=medium,fill='#d7e5f5')
    ar('الوقت',885,599,fill='#bcc8d9',f=tiny)
    d.text((1060,599),str(event.get('ts') or 'غير محدد'),font=tiny,fill='#bcc8d9',anchor='ra')
    p=(str(round(event['x'],1))+', '+str(round(event['z'],1))) if event.get('x') is not None and event.get('z') is not None else '—'
    d.text((48,603),'X / Z: '+p,font=tiny,fill='#bbc4d3')
    buf=io.BytesIO();im.save(buf,'PNG');return buf.getvalue()


def event_can_send(event):
    # We never send unfinished trades as completed transactions.
    return event['kind']!='trade' or event['action']=='COMPLETE'


def event_auto_allowed(event):
    return ((event['kind']=='trade' and event['action']=='COMPLETE')
            or (event['kind']=='combat' and event['action']=='PVP_KILL')
            or (event['kind']=='player' and event['action'] in {'LOGIN','LOGOUT'})
            or (event['kind']=='raid' and event['action']=='DESTROYED')
            or (event['kind']=='court' and event['action'] in {'PRISON','FREE','HELD_FOR_TRIAL'})
            or (event['kind']=='vehicle' and event['action'] in {'REGISTER','REPLACE','TRANSFER','REKEY'})
            or (event['kind']=='bank' and event['action'] not in {'BALANCE_SNAPSHOT'})
            or (event['kind']=='trader' and event['action']!='OBJECT_SPAWN')
            or (event['kind']=='mod_update' and event['action']=='server.updated_mod')
            or (event['kind']=='server_health' and event['action'] in {'server.started','server.stopped','STOPPED','RECOVERED'}))


def send_discord(event, webhook):
    check_webhook(webhook)
    if not event_can_send(event):raise ValueError('لا يمكن إرسال صفقة لم تكتمل')
    png=image_trade(event) if event['kind']=='trade' else image_event(event)
    category=WEBHOOK_KINDS.get(event['kind'],event['kind'])
    boundary='----APX'+uuid.uuid4().hex
    message='ARAB PRO | '+category+' | '+str(event.get('action') or '')
    if event['kind']=='mod_update':
        extra=json.loads(event.get('extra') or '{}')
        message='🐺 تحديث مود ARAB PRO: '+str(extra.get('mod_name') or event.get('item') or '')[:150]+' — تم تطبيقه على السيرفر'
        mod_id=str(extra.get('mod_id') or '')
        if mod_id.isdigit():message+='\nhttps://steamcommunity.com/sharedfiles/filedetails/?id='+mod_id
    if event['kind']=='server_health':
        extra=json.loads(event.get('extra') or '{}')
        lines=[str(x.get('line') or '')[:180] for x in (extra.get('diagnostics') or [])[-2:] if isinstance(x,dict)]
        if event['action']=='STOPPED':
            message='🔴 ARAB PRO: توقف سيرفر DayZ عن العمل. السبب غير مؤكد.'
            if lines:message+='\nآخر مؤشرات الأخطاء (ليست تشخيصًا مؤكدًا):\n'+'\n'.join(lines)
        elif event['action']=='RECOVERED':message='🟢 ARAB PRO: عادت عملية سيرفر DayZ للعمل.'
        else:message='ARAB PRO | '+category+' | '+str(event.get('action') or '')
    # Discord accepts payload_json and a PNG attachment in one multipart POST.
    body=(('--'+boundary+'\r\nContent-Disposition: form-data; name="payload_json"\r\nContent-Type: application/json\r\n\r\n'+
        json.dumps({'content':message[:1800]},ensure_ascii=False)+'\r\n--'+boundary+
        '\r\nContent-Disposition: form-data; name="file"; filename="arab_pro_report.png"\r\nContent-Type: image/png\r\n\r\n').encode('utf-8')+
        png+('\r\n--'+boundary+'--\r\n').encode('ascii'))
    req=urllib.request.Request(webhook,data=body,headers={
       'Content-Type':'multipart/form-data; boundary='+boundary,'User-Agent':'ArabProAdminCenter/1.2'})
    with urllib.request.urlopen(req,timeout=20) as resp:
        if resp.status not in (200,204):raise ValueError('Discord HTTP '+str(resp.status))


def queue_new_auto_events(server, ids):
    if not ids:return 0
    conf=init_config()['webhooks'][server]
    counter={kind:0 for kind in WEBHOOK_KINDS}
    n=0
    with db() as c:
        for eid in ids:
            ev=as_dict(c.execute('SELECT * FROM events WHERE server=? AND id=?',(server,eid)).fetchone())
            if not ev or ev['kind'] not in conf:continue
            kind=ev['kind'];setting=conf[kind]
            if not (setting.get('url') and setting.get('enabled') and setting.get('auto')):continue
            if eid <= int(setting.get('min_id') or 0) or not event_auto_allowed(ev):continue
            # Do not flood Discord from a giant imported archive: at most 20 per kind per scan.
            if counter[kind]>=20:continue
            c.execute('INSERT OR IGNORE INTO webhook_deliveries(server,event_id,kind,status) VALUES(?,?,?,?)',
                      (server,eid,kind,'pending'))
            n+=c.execute('SELECT changes()').fetchone()[0]
            counter[kind]+=1
    return n


def is_old_trade_delivery(c,server,ev):
    if ev['kind']!='trade':return False
    tid=str(json.loads(ev['extra'] or '{}').get('tradeId') or '')
    row=c.execute('SELECT 1 FROM outbox WHERE event_id=? OR trade_id=?',
                  (ev['id'],server+':'+tid if tid else '___never___')).fetchone()
    if row:return True
    if tid and c.execute('SELECT 1 FROM webhook_sent_keys WHERE server=? AND kind=? AND external_key=?',
                         (server,'trade',tid)).fetchone():return True
    return False


def queue_manual_event(server,eid):
    conf=init_config()['webhooks'][server]
    with db() as c:
        ev=as_dict(c.execute('SELECT * FROM events WHERE id=? AND server=?',(eid,server)).fetchone())
        if not ev:raise ValueError('الحدث غير موجود على هذا السيرفر')
        kind=ev['kind']
        setting=conf.get(kind)
        if not setting or not (setting.get('enabled') and setting.get('url')):
            raise ValueError('اضبط وفعّل Webhook قسم '+WEBHOOK_KINDS.get(kind,kind)+' أولًا')
        if not event_can_send(ev):raise ValueError('الصفقة لم تكتمل بعد')
        if is_old_trade_delivery(c,server,ev):raise ValueError('هذه الصفقة أُرسلت سابقًا إلى Discord')
        old=c.execute('SELECT status FROM webhook_deliveries WHERE server=? AND event_id=? AND kind=?',
                      (server,eid,kind)).fetchone()
        if old and old['status'] in {'sent','sending','pending'}:
            raise ValueError('تقرير هذا الحدث سبق إرساله أو هو قيد الإرسال؛ منعنا التكرار')
        if old:
            c.execute('UPDATE webhook_deliveries SET status=?,error=? WHERE server=? AND event_id=? AND kind=?',
                      ('pending','',server,eid,kind))
        else:
            c.execute('INSERT INTO webhook_deliveries(server,event_id,kind,status) VALUES(?,?,?,?)',
                      (server,eid,kind,'pending'))


def deliver_one(server,eid,from_queue=False):
    with DELIVERY_LOCK:
        with db() as c:
            rec=c.execute('SELECT status FROM webhook_deliveries WHERE server=? AND event_id=?',(server,eid)).fetchone()
            if not rec or rec['status']!='pending':
                if from_queue:return False
                raise ValueError('الإرسال غير متاح أو سبق إرسال الحدث')
            ev=as_dict(c.execute('SELECT * FROM events WHERE server=? AND id=?',(server,eid)).fetchone())
            if ev and is_old_trade_delivery(c,server,ev):
                c.execute('UPDATE webhook_deliveries SET status=?,error=? WHERE server=? AND event_id=?',
                          ('skipped','مكرر أو أُرسل في إصدار سابق',server,eid))
                if from_queue:return False
                raise ValueError('هذه الصفقة أُرسلت سابقًا إلى Discord')
            c.execute('UPDATE webhook_deliveries SET status=?,attempts=attempts+1 WHERE server=? AND event_id=?',('sending',server,eid))
        try:
            if not ev:raise ValueError('حدث غير موجود')
            setting=init_config()['webhooks'][server].get(ev['kind'])
            if not setting or not setting.get('enabled') or not setting.get('url'):
                raise ValueError('Webhook غير مفعّل')
            send_discord(ev,setting['url'])
        except Exception as ex:
            with db() as c:
                c.execute('UPDATE webhook_deliveries SET status=?,error=? WHERE server=? AND event_id=?',
                          ('failed',str(ex)[:250],server,eid))
            if from_queue:return False
            raise
        with db() as c:
            if ev['kind']=='trade':
                tid=str(json.loads(ev['extra'] or '{}').get('tradeId') or '')
                if tid:
                    c.execute('INSERT OR IGNORE INTO webhook_sent_keys(server,kind,external_key,event_id) VALUES(?,?,?,?)',
                              (server,'trade',tid,eid))
            c.execute('UPDATE webhook_deliveries SET status=?,sent_at=CURRENT_TIMESTAMP,error=? WHERE server=? AND event_id=?',
                      ('sent','',server,eid))
        return True


def delivery_worker():
    while True:
        try:
            with db() as c:
                pending=c.execute("SELECT server,event_id FROM webhook_deliveries WHERE status='pending' ORDER BY created_at ASC,event_id ASC LIMIT 10").fetchall()
            for rec in pending:deliver_one(rec['server'],rec['event_id'],from_queue=True)
        except Exception as ex:print('[DISCORD DELIVERY WARNING]',str(ex))
        time.sleep(6)


def query_search_args(query):
    return {x:query.get(x,[''])[0] for x in ('q','action','date_from','date_to','time_from','time_to')}


def csv_export(headers,records):
    buf=io.StringIO()
    w=csv.writer(buf)
    w.writerow(headers)
    for item in records:
        # Prevent spreadsheet formula injection in text fields.
        values=[]
        for key in headers:
            value=item.get(key,'')
            if isinstance(value,(dict,list)):value=json.dumps(value,ensure_ascii=False)
            if isinstance(value,str) and value.startswith(('=','+','-','@')):value="'"+value
            values.append(value)
        w.writerow(values)
    return ('\ufeff'+buf.getvalue()).encode('utf-8')

class Handler(BaseHTTPRequestHandler):
    server_version='ArabProLocal/1.0'
    def log_message(self,*args):pass
    def reply(self,data,status=200,ctype='application/json; charset=utf-8'):
        raw=(json.dumps(data,ensure_ascii=False,default=str).encode('utf-8') if not isinstance(data,bytes) else data)
        self.send_response(status);self.send_header('Content-Type',ctype);self.send_header('Content-Length',str(len(raw)))
        self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Content-Security-Policy',"default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'")
        self.end_headers();self.wfile.write(raw)
    def get_server(self,query):
        server=query.get('server',['test'])[0]
        if server not in VALID_SERVERS:raise ValueError('السيرفر غير معروف')
        return server
    def same_origin(self):
        origin=self.headers.get('Origin')
        port=self.server.server_port
        return not origin or origin in {'http://127.0.0.1:'+str(port),'http://localhost:'+str(port)}
    def do_GET(self):
        url=urllib.parse.urlparse(self.path)
        q=urllib.parse.parse_qs(url.query)
        try:
            if url.path=='/':return self.reply((APP/'index.html').read_bytes(),ctype='text/html; charset=utf-8')
            if url.path=='/logo.png':return self.reply((APP/'assets/logo.png').read_bytes(),ctype='image/png')
            if url.path=='/api/servers':
                conf=init_config();return self.reply({'servers':conf['servers'],
                                  'architect':conf['architect'],
                                  'webhook_kinds':WEBHOOK_KINDS,'health':conf.get('health',{}),'scan_interval_seconds':conf.get('scan_interval_seconds',5),
                                  'webhooks':{s:{k:{'configured':bool(v.get('url')),
                                      'enabled':bool(v.get('enabled')),'auto':bool(v.get('auto'))}
                                      for k,v in conf['webhooks'][s].items()} for s in VALID_SERVERS}})
            if url.path=='/api/architect/deployments':return self.reply(discover_architect_deployments())
            server=self.get_server(q)
            if url.path=='/api/map-image':
                path=map_image_path(server)
                if not path.is_file():return self.reply({'error':'No map image configured'},404)
                return self.reply(path.read_bytes(),ctype='image/png')
            if url.path=='/api/map-points':
                return self.reply(map_data(server,q.get('q',[''])[0],q.get('action',[''])[0],
                    q.get('date_from',[''])[0],q.get('date_to',[''])[0],
                    q.get('time_from',[''])[0],q.get('time_to',[''])[0],q.get('kinds',[''])[0]))
            if url.path=='/api/overview':return self.reply(overview(server))
            if url.path=='/api/attendance':return self.reply(attendance_stats(server,q.get('date_from',[''])[0],q.get('date_to',[''])[0]))
            if url.path=='/api/health':return self.reply({'monitor':health_snapshot(server),'diagnostics':diagnostics(server)})
            opts=query_search_args(q)
            if url.path=='/api/event-actions':return self.reply({'actions':actions_list(server,q.get('kind',[''])[0])})
            if url.path=='/api/events':return self.reply({'events':events(server,q.get('kind',[''])[0],limit=q.get('limit',['500'])[0],player_uid=q.get('player_uid',[''])[0],**opts)})
            if url.path=='/api/players':return self.reply({'players':player_list(server,opts['q'],opts['date_from'],opts['date_to'],opts['time_from'],opts['time_to'])})
            if url.path=='/api/bases':return self.reply({'bases':bases_filtered(server,opts['q'],opts['date_from'],opts['date_to'],opts['time_from'],opts['time_to'])})
            if url.path=='/api/sources':return self.reply({'sources':sources_filtered(server,opts['q'],opts['date_from'],opts['date_to'],opts['time_from'],opts['time_to'])})
            if url.path in {'/api/trade-image','/api/event-image'}:
                eid=int(q.get('id',['0'])[0]);
                with db() as c:ev=as_dict(c.execute('SELECT * FROM events WHERE server=? AND id=?',(server,eid)).fetchone())
                if not ev:raise ValueError('حدث غير موجود')
                return self.reply(image_trade(ev) if ev['kind']=='trade' else image_event(ev),ctype='image/png')
            if url.path in {'/api/export.csv','/api/export-view.csv'}:
                view=q.get('view',['events'])[0] if url.path.endswith('view.csv') else 'events'
                if view=='map':
                    map_result=map_data(server,opts['q'],opts['action'],opts['date_from'],opts['date_to'],
                                        opts['time_from'],opts['time_to'],q.get('kinds',[''])[0])
                    items=map_result['events']
                    fields=['ts','kind','action','resolved_player_name','player_name','player_id',
                            'resolved_target_name','target_name','target_id','item','x','y','z','details']
                elif view in {'events','raids','trades','dashboard','playeractivity','court','vehicles','combat','healthlog','mods','bank','trader'}:
                    kind={'raids':'raid','trades':'trade','court':'court','vehicles':'vehicle','combat':'combat','healthlog':'server_health','mods':'mod_update','bank':'bank','trader':'trader'}.get(view,q.get('kind',[''])[0])
                    amount={'dashboard':15,'playeractivity':250,'raids':600,'trades':600,'court':1000,'vehicles':1000,'combat':1000,'healthlog':1000,'mods':600,'bank':900,'trader':900,'events':2000}[view]
                    items=events(server,kind,limit=amount,player_uid=q.get('player_uid',[''])[0],**opts)
                    fields=['ts','kind','action','player_name','player_id','target_name','target_id','item','x','y','z','details','source']
                elif view=='attendance':
                    items=attendance_stats(server,q.get('date_from',[''])[0],q.get('date_to',[''])[0])['sessions']
                    fields=['name','uid','start','end','minutes']
                elif view=='players':
                    items=player_list(server,opts['q'],opts['date_from'],opts['date_to'],opts['time_from'],opts['time_to'])
                    fields=['name','uid','aliases','last_seen']
                elif view=='bases':
                    items=bases_filtered(server,opts['q'],opts['date_from'],opts['date_to'],opts['time_from'],opts['time_to'])
                    fields=['name','owner_name','owner_id','x','z','radius','note','created_at']
                elif view=='sources':
                    items=sources_filtered(server,opts['q'],opts['date_from'],opts['date_to'],opts['time_from'],opts['time_to'])
                    fields=['path','size','mtime','updated_at']
                else:raise ValueError('قسم التصدير غير معروف')
                return self.reply(csv_export(fields,items),ctype='text/csv; charset=utf-8')
            return self.reply({'error':'Not found'},404)
        except Exception as ex:return self.reply({'error':str(ex)},400)
    def do_POST(self):
        url=urllib.parse.urlparse(self.path)
        if url.path.startswith('/api/architect/ingest/'):
            try:
                conf=init_config()
                expected=conf['architect'].get('token','')
                token=url.path.split('/')[-1]
                if not expected or not hmac.compare_digest(token,expected):
                    return self.reply({'error':'Unauthorized'},403)
                if self.headers.get('X-WebHook')!='Architect Agent':
                    return self.reply({'error':'Source header missing'},403)
                kind=str(self.headers.get('X-WebHook-Event') or '')
                idem=str(self.headers.get('X-Event-Idempotence') or '').strip()
                if not idem or len(idem)>150:return self.reply({'error':'Idempotence header required'},400)
                length=int(self.headers.get('Content-Length') or '0')
                if not 0<length<=8192:return self.reply({'error':'Invalid payload size'},413)
                data=json.loads(self.rfile.read(length).decode('utf-8'))
                if not isinstance(data,dict):raise ValueError('JSON object required')
                return self.reply(architect_record(kind,data,idem))
            except Exception as ex:return self.reply({'error':str(ex)},400)
        if not self.same_origin():return self.reply({'error':'Origin blocked'},403)
        if url.path=='/api/map-image-reset':
            try:
                params=urllib.parse.parse_qs(url.query)
                server=self.get_server(params)
                override=DATA/'maps'/(server+'.png')
                if override.is_file():override.unlink()
                return self.reply({'ok':True,'map_image_source':map_image_source(server)})
            except Exception as ex:return self.reply({'error':str(ex)},400)
        if url.path=='/api/map-image':
            try:
                params=urllib.parse.parse_qs(url.query)
                server=self.get_server(params)
                if self.headers.get('Content-Type','').split(';')[0].strip().lower()!='image/png':
                    raise ValueError('اختر صورة PNG فقط')
                length=int(self.headers.get('Content-Length') or '0')
                if not 32<=length<=12*1024*1024:raise ValueError('حجم صورة الخريطة يتجاوز 12 ميجابايت أو غير صالح')
                raw=self.rfile.read(length)
                if not raw.startswith(b'\x89PNG\r\n\x1a\n') or raw[12:16]!=b'IHDR':
                    raise ValueError('ملف PNG غير صحيح')
                width=int.from_bytes(raw[16:20],'big');height=int.from_bytes(raw[20:24],'big')
                if not 512<=width<=16384 or not 512<=height<=16384:
                    raise ValueError('حجم الصورة بالبكسل يجب بين 512 و16384')
                # A square source image is required for 1:1 X/Z scaling.
                if width!=height:raise ValueError('يجب أن تكون صورة الخريطة مربعة وتحمل كامل مساحة 15360×15360 متر')
                dest=DATA/'maps';dest.mkdir(exist_ok=True)
                path=dest/(server+'.png');tmp=dest/(server+'.tmp')
                tmp.write_bytes(raw);os.replace(tmp,path)
                return self.reply({'ok':True,'width':width,'height':height})
            except Exception as ex:return self.reply({'error':str(ex)},400)
        url=urllib.parse.urlparse(self.path)
        try:
            size=int(self.headers.get('Content-Length',0))
            if size>65536:raise ValueError('طلب كبير')
            d=json.loads(self.rfile.read(size).decode('utf-8')) if size else {}
            server=str(d.get('server','test'))
            if server not in VALID_SERVERS:raise ValueError('سيرفر غير معروف')
            if url.path=='/api/architect/set-deployments':
                root=str(d.get('directory') or '').strip()
                if not Path(root).is_dir():raise ValueError('مجلد Architect غير موجود على جهاز الخدمة')
                conf=init_config();conf['architect']['deployments_dir']=root;save_config(conf)
                return self.reply(discover_architect_deployments(conf))
            if url.path=='/api/architect/link':
                return self.reply(link_architect_deployment(d.get('deployment_id',''),d.get('target',''),d.get('name','')))
            if url.path=='/api/scan':return self.reply(scan(server))
            if url.path=='/api/health/config':
                match=str(d.get('match','')).strip()[:160]
                enabled=bool(d.get('enabled'))
                if enabled and len(match)<5:raise ValueError('أدخل جزءًا فريدًا من سطر تشغيل السيرفر (5 أحرف على الأقل)')
                with CONFIG_LOCK:
                    conf=init_config()
                    conf.setdefault('health',{})[server]={'match':match,'enabled':enabled}
                    save_config(conf)
                with HEALTH_LOCK: HEALTH_STATE.pop(server,None)
                return self.reply({'ok':True,'monitor':health_snapshot(server)})
            if url.path=='/api/scan-config':
                seconds=int(d.get('seconds',5))
                if not 5<=seconds<=120:raise ValueError('فترة الفحص من 5 إلى 120 ثانية')
                with CONFIG_LOCK:
                    conf=init_config();conf['scan_interval_seconds']=seconds;save_config(conf)
                return self.reply({'ok':True,'seconds':seconds})
            if url.path=='/api/pick-folder':
                # Only a local browser at this machine can use this endpoint.
                # A single dialog is allowed at a time to avoid overlapped windows.
                if not folder_pick_lock.acquire(blocking=False):
                    raise ValueError('نافذة اختيار المجلد مفتوحة بالفعل')
                try:
                    conf = init_config()
                    current = str(conf['servers'][server].get('root') or '')
                    initial = current if current and Path(current).is_dir() else str(Path.home())
                    selected = choose_server_folder(initial)
                    if not selected:
                        return self.reply({'ok': False, 'cancelled': True, 'root': current})
                    if not Path(selected).is_dir():
                        raise ValueError('المجلد الذي اخترته غير موجود أو لا يمكن الوصول إليه')
                    conf = init_config()
                    conf['servers'][server]['root'] = selected
                    save_config(conf)
                    return self.reply({'ok': True, 'cancelled': False, 'root': selected})
                finally:
                    folder_pick_lock.release()
            if url.path=='/api/set-root':
                root=str(d.get('root','')).strip()
                if root and not Path(root).is_dir():raise ValueError('مسار المجلد غير موجود على نفس جهاز الخدمة')
                conf=init_config();conf['servers'][server]['root']=root;save_config(conf)
                return self.reply({'ok':True})
            if url.path=='/api/base':
                name=str(d.get('name','')).strip()[:100]
                if not name:raise ValueError('أدخل اسم القاعدة')
                x,z,r=float(d['x']),float(d['z']),float(d['radius'])
                if r<5 or r>1000:raise ValueError('نصف القطر بين 5 و1000 متر')
                owner=str(d.get('owner_id','')).strip()
                if owner and not UID_RE.fullmatch(owner):raise ValueError('SteamID غير صحيح')
                with db() as c:c.execute('INSERT INTO bases(server,name,owner_id,x,z,radius,note) VALUES(?,?,?,?,?,?,?)',(server,name,owner,x,z,r,str(d.get('note',''))[:500]))
                return self.reply({'ok':True})
            if url.path=='/api/delete-base':
                with db() as c:c.execute('DELETE FROM bases WHERE id=? AND server=?',(int(d['id']),server))
                return self.reply({'ok':True})
            if url.path=='/api/webhook':
                kind=str(d.get('kind',''))
                if kind not in WEBHOOK_KINDS:raise ValueError('قسم Webhook غير معروف')
                url_value=str(d.get('webhook','')).strip()
                if url_value:check_webhook(url_value)
                with CONFIG_LOCK:
                    conf=init_config()
                    item=conf['webhooks'][server][kind]
                    if bool(d.get('clear')):
                        item.update({'url':'','enabled':False,'auto':False})
                    else:
                        if url_value:item['url']=url_value
                        item['enabled']=bool(d.get('enabled'))
                        auto=bool(d.get('auto'))
                        if auto and not item['enabled']:raise ValueError('فعّل القسم أولًا')
                        if item['enabled'] and not item.get('url'):raise ValueError('أدخل رابط Webhook لهذا القسم')
                        if auto and not item.get('auto'):
                            # Historical backlog safeguard: first load logs, then enable auto.
                            with db() as c:
                                num=c.execute('SELECT COUNT(*) FROM sources WHERE server=?',(server,)).fetchone()[0]
                                if not num and kind not in {'mod_update','server_health'}:raise ValueError('افحص سجلات السيرفر أولًا قبل تفعيل الإرسال التلقائي')
                                item['min_id']=c.execute('SELECT COALESCE(MAX(id),0) FROM events WHERE server=?',(server,)).fetchone()[0]
                        item['auto']=auto
                    save_config(conf)
                return self.reply({'ok':True})
            if url.path in {'/api/send-event','/api/send-trade'}:
                eid=int(d['id'])
                queue_manual_event(server,eid)
                deliver_one(server,eid)
                return self.reply({'ok':True})
            return self.reply({'error':'Not found'},404)
        except Exception as ex:return self.reply({'error':str(ex)},400)

def scheduled_scan():
    while True:
        try:
            conf=init_config()
            for server in list(VALID_SERVERS):
                if conf['servers'][server].get('root'):scan(server)
            time.sleep(max(5,min(120,int(conf.get('scan_interval_seconds',5)))))
        except Exception as ex:
            print('[SCAN WARNING]',str(ex));time.sleep(30)

if __name__=='__main__':
    args=argparse.ArgumentParser();args.add_argument('--scan-only');args.add_argument('--port',type=int,default=8765);args=args.parse_args()
    setup();init_config()
    if args.scan_only:print(scan(args.scan_only));raise SystemExit(0)
    if args.port<1 or args.port>65535:raise ValueError('Port not valid')
    threading.Thread(target=scheduled_scan,daemon=True).start()
    threading.Thread(target=delivery_worker,daemon=True).start()
    threading.Thread(target=health_monitor,daemon=True).start()
    print('ARAB PRO Admin Center: http://127.0.0.1:'+str(args.port))
    print('Local access only. Files are read-only. Press Ctrl+C to stop.')
    ThreadingHTTPServer(('127.0.0.1',args.port),Handler).serve_forever()
